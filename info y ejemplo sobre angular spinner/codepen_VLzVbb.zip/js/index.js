angular.module('spinnerDemo', ['angularSpinners'])
  .controller('loginCtrl', function ($scope, $timeout, spinnerService) {
    $scope.login = function () {
      spinnerService.show('html5spinner');
      $timeout(function () {
        spinnerService.hide('html5spinner');
        $scope.loggedIn = true;
      }, 2500);
    };
  });